sheep.addEventListener('click', function () {
    console.log('sheep');
    document.getElementById('animals').src = 'sheep.webp';
}
)
beer.addEventListener('click', function () {
    console.log('beer');
    document.getElementById('animals').src = 'bear.webp';
}
)
moose.addEventListener('click', function () {
	console.log('moose');
    document.getElementById('animals').src = 'moose.webp';
}
)
wolf.addEventListener('click', function () {
	console.log('wolf');
    document.getElementById('animals').src = 'wolf.webp';
}
)
elk.addEventListener('click', function () {
	console.log('elk');
    document.getElementById('animals').src = 'elk.webp';
}
)
